# READ ME ####

# This R code and data are free to download, copy, use and 
# modify. If improvements to analysis are discussed on forums, 
# groups, universities or research institutes, please 
# send a copy of the suggested changes to the R code author, G. Wood at 
# gavinwood1@yahoo.co.uk, to improve future uses for UK forestry data analysis. 
# A copy of the report this code and data apply to, An evaluation of 
# Pinus peuce for UK forestry plus a novel imbibition test, can be found at 
# hartfordlabs.weebly.com.

# Who: Gav contact gavinwood1@yahoo.co.uk 07491 161270
# Data available at https://github.com/HL-R/Novel-imbibition-test-2.git
# Last edit 16 August 2022
# Title: Absorption and germination tests for a Read Report potential UK 
# adapatation species; challenged with inconsistent germination inter alia.

# Set working directory in Session

# Contents ####
# Null hypotheses
# Clear decks
# Packages
# Data
# Differences in weight by predictors
# Group means
# Model
# Assumptions
# Contrasts to test Null hypothesis 1 & 2
# Differences in germination by predictors
# Model
# Test fit (Assumptions)
# Contrasts to test Null hypothesis 3 & 4
# Dispersion remodelling exercise

# Null hypotheses ####
# Hypothesis 1. H0 There is no significant difference in weight change (mg) 
# between treatments after a set duration of imbibition.

# Hypothesis 2. H0 There is no significant difference in weight change (mg) 
# for a single treatment after different durations of imbibition.

# Hypothesis 3. H0 There is no significant difference in germination probability 
# between treatments within 30 days after a set duration of imbibition.

# Hypothesis 4. H0 There is no significant difference in germination probability 
# from the same treatment after different durations of imbibition.

# Independent samples for each duration i.e not repeated measures.

# Independent factor: treatment w/3 levels: Control (NT), Standard (S) and Dynamic (D).
# Independent factor: time w/4 levels: 72 (72), 168 (168), 336 (336) and 672 (672) hours.
# Independent continuous covariate: Initial weights mean (mg)
# 3 x 4 x 1 predictors = 12 combinations. 
# Each combination had 31 seeds.
# Each combination (a.k.a. a Plate) was replicated four times. 12 x 31 x 4 = N=1488
# A plate represents an imbibition beaker in Hyp1&2 and a Petri dish in Hyp3&4.
# Replicates were not modeled for random variation as too few for
# parametric inference (https://www.mdpi.com/2306-5729/5/1/6/htm)
# and https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3321166/pdf/embor201236a.pdf
# Replicate dish means were used for planned comparisons.
# Dependent variable Hyp 1 & 2 numeric: Final weights mean (mg)
# Dependent variable Hyp 3 & 4 numeric: Germination (probability)

# Clear the decks ####

rm(list = ls())

# Packages ####

library(readr)
library(ggplot2)
library(dplyr)
library(lme4)
library(rstatix)
library(broom)
library(performance)
library(effects)
library(visreg, warn.conflicts=FALSE)
library(moments)
library(normtest)
library(car)
library(lmtest)
library(emmeans)
library(ggfortify)
library(DHARMa)

# Power

# G*Power ANCOVA: Fixed effects, main effects and interactions:
# Es = 0.25, a = 0.05, Power = 0.97, Numerator Df = 6, Number of groups = 12
# (12 cells), Number of covariates = 1: N=372/12 = n=31

# G*Power Exact generic binomial: Tails = Two, p2 = 0.16, a = 0.05, total sample size =
# 1488, p1 = 0.12, Power = 0.99.

# Data ####

ab <- read.csv("Projects/Absorption/672/672.weights.full.csv")
ab <- ab[,-9]
head(ab)
str(ab)

ab$treatment <-  as.factor(ab$treatment)
ab$imb.or.dry <-  as.factor(ab$imb.or.dry)
ab$rep.no <-  as.factor(ab$rep.no)
ab$weight <-  as.numeric(ab$weight)
ab$time <-  as.factor(ab$time)
ab$ID <-  as.factor(ab$ID)
ab$Seed <- as.factor(ab$Seed)
ab$halfid <- as.factor(ab$halfid)
str(ab)
ab$treatment <- factor(ab$treatment,levels = c("nt", "s", "d")) 
levels(ab$treatment)
levels(ab$treatment) <- c("control", "s", "d")
levels(ab$time)
levels(ab$time) <- c("72 Hours", "168 Hours", "336 Hours", "672 Hours")
str(ab)

median(ab$weight[1:1488])
max(ab$weight[1:1488]) # Adjust min for minimum
quantile(ab$weight[1:1488])

# Difference between dry and imbibed weights by predictors####
# Optimal change index: https://journals.physiology.org/doi/pdf/10.1152/advan.00018.2015

# Group means keeping replicate plates separate in data.frame for within-group error #### 

c1 <- ab %>%
  group_by(imb.or.dry, treatment, time, rep.no) %>%
  summarise(
    mean = mean(weight)) %>% ungroup() %>% as.data.frame

(c2 <- c1[1:48,2:5])
names(c2) <- c("treatment", "time", "rep", "initialmeanmg")
c2$finalmeanmg <- c1$mean[49:96]
c2$abdif <- (c2$finalmeanmg - c2$initialmeanmg) # Absolute change
c2$pcdif <- (c2$finalmeanmg - c2$initialmeanmg) / (c2$initialmeanmg) * 100 # Relative change
c2$symdif <- ((c2$finalmeanmg - c2$initialmeanmg) / (c2$finalmeanmg + c2$initialmeanmg)) * 100 # Symmetrised relative change

ggplot(c2, aes(x = initialmeanmg, y = finalmeanmg, colour = treatment)) +
  geom_point(size = 2) +
  geom_smooth(method = lm, size = I(1), se = FALSE) +
  xlab("Initial mean (mg)") +
  ylab("Final mean (mg)") +
  facet_wrap(~time) +
  theme_classic() # Meets the final model ANCOVA assumption of linear 
# relationship between response and covariate at each levels of treatment (see report appendix)

# Exploratory graph

scatterplot(y=c2$finalmeanmg,x=c2$initialmeanmg)
# Positive correlation between initial mean (mg) and final mean (mg).
# Change indices (abdif and pcdif) show a negative correlation with initial mean.

cor.test(c2$initialmeanmg, c2$finalmeanmg)
# There is a significant correlation between the initial mean and final mean 
# (Pearson's correlation r = 0.48, Df = 46, P<0.001) which can be controlled for.

# Model ####

c2.m <- lm(finalmeanmg ~ initialmeanmg + treatment + time, data = c2)

# Assumptions ####

residualPlots(c2.m)
# Pearson v initial, residuals quadratic regression=solid line lack-of-fit test, Initialmean no lack-of-fit p = 0.78.
# Pearson v fitted, fitted values squared then refitted=solid line Tukey test stat v Gaussian. Seems Ok P = 0.96.

plot(resid(c2.m))
# Residuals seem a little heteroscedastic.

# Remodel and compare heteroscedasticity

c2$log.finalmeanmg <- log(c2$finalmeanmg)

c3.m <- lm(log.finalmeanmg ~ initialmeanmg + treatment + time, data = c2)

residualPlots(c3.m)
# Residuals vs fitted still look a little heteroscedastic. The fit against Gaussian looks OK.

# Compare more models

c4.m <- lmer(finalmeanmg ~ initialmeanmg + treatment + time + (1 |rep), data = c2, REML = TRUE) # Concern of overfitting as inferring parametric random variance estimates from only 4 plates.
                                                                                   
plot(c4.m)
# Not much better, nor log or arcsine to both meanmg's together.

c5.m <- lmer(finalmeanmg ~ initialmeanmg + treatment * time + (1 | rep), data = c2, REML = TRUE) # Concern of overfitting

plot(c5.m)
# Close to best.

c6.m <- lmer(finalmeanmg ~ initialmeanmg + treatment * time + (treatment | rep), data = c2,REML = TRUE) # Concern of overfitting

plot(c6.m)
# Not as good as the last one.

c7.m <- lmer(finalmeanmg ~ initialmeanmg + treatment + time + (treatment | rep), data = c2, REML = TRUE) # Concern of overfitting

plot(c7.m)
# Not as good as close to best.

c8.m <- lm(finalmeanmg ~ initialmeanmg + treatment * time, data = c2)

residualPlots(c8.m) 
# Best to me on res v fit. Time and Treatment plots look reasonable. Top left potential influencers near 64 and 74mg. 

#Compare resid v index plots
plot(resid(c2.m)) # Relatively not bad
plot(resid(c3.m)) # Similar
plot(resid(c4.m)) # Close to c2.m
plot(resid(c5.m)) # Pretty good
plot(resid(c6.m)) # Looks Ok
plot(resid(c7.m)) # Similar to c2:4.m
plot(resid(c8.m)) # Looks best to me

# compare AIC # except c3.m as difference response. Set REML = FALSE above on mixed-models before comparing.
AIC(c8.m, c7.m, c6.m, c5.m, c4.m, c2.m) # c2.m lowest AIC by 2
       
r2(c5.m) # Not used. R2m explained by fixed effects; R2c by fixed and random. https://jonlefcheck.net/2013/03/13/r2-for-linear-mixed-effects-models/

anova(c5.m, c2.m) # lmer first. No significant difference, c2.m lower (AIC=5.07, Df=7, P=0.26). Continue with c2.m.

# Reset default lmer REML=TRUE if using a lmer (Set to FALSE just for better AIC comparisons).

# Compare c2.m with and without the interaction visually and statistically

# Overall model fit (Adjusted means see predictor effects vignette https://cran.r-project.org/web/packages/effects/vignettes/predictor-effects-gallery.pdf)

plot(predictorEffects(c2.m, residuals=TRUE), 
     axes=list(grid=TRUE, x=list(rotate=30)),
     partial.residuals=list(smooth=TRUE, span=0.75, lty="dashed"))

plot(predictorEffects(c8.m, residuals=TRUE), 
     axes=list(grid=TRUE, x=list(rotate=30)),
     partial.residuals=list(smooth=TRUE, span=0.75, lty="dashed"))

# Effect combinations visualise lack-of-fit w w/o interaction

plot(Effect(c("treatment", "time"), c2.m, residuals = TRUE),
     partial.residual = list(lty = ""),
     ylab = "Final weight mean (mg)",
     main = "Additive model: treatment & time effect on the model \nusing the initial weight mean (mg) average + residuals")

plot(Effect(c("treatment", "time"), c8.m, residuals = TRUE),
     partial.residual = list(lty = ""),
     ylab = "Final weight mean (mg)",
     main = "Interactive model: treatment & time effect on the model \nusing the initial weight mean (mg) average + residuals")

plot(Effect(c("time", "treatment"), c2.m, residuals = TRUE),
     partial.residual = list(lty = ""),
     ylab = "Final weight mean (mg)", rotx={20},
     main = "Additive model: time & treatment effect on the model \nusing the initial weight mean (mg) average + residuals")

plot(Effect(c("time", "treatment"), c8.m, residuals = TRUE),
     partial.residual = list(lty = ""),
     ylab = "Final weight mean (mg)", rotx={20},
     main = "Interactive model: time & treatment effect on the model \nusing the initial weight mean (mg) average + residuals")

# The interactive Effect models' adjusted means (Blue dots) look closer fits to the partial residual means (Magenta 
# dots). The Effect plots use the initialmeanmg average. The additive plots highlights unexplained replicate 
# partial errors outside 95% CI. Control 72 and 672 Hours, and S 336 Hours unexplained partial errors look 
# relatively high. The interaction model 95% CI includes more control 72 partial residual errors but is a larger CI.

visreg(
  c2.m,
  xvar = "treatment", 
  by = "time", gg=TRUE, 
  points.par=list(size=1.5, col = "darkgoldenrod4")
) 
# One-row view of Additive treatment & time Effect.  

visreg(
  c8.m,
  xvar = "treatment", 
  by = "time", gg=TRUE,
  points.par=list(size=1.5, col = "darkgoldenrod4")
) 
# One-row view of Interactive treatment & time Effect.
# The interactive model appears to capture more of the residuals in 95% confidence bands by 
# expanding and shifting the confidence limits)

# Visualise discreet time and treatment levels in residual v fitted slopes. (not used)

residualPlots(c2.m, terms= ~ 1 | time, xlim=c(85, 103), ylim=c(-7, 7))
# The additive model time residuals variance slopes appear relatively constant between durations.
residualPlots(c8.m, terms= ~ 1 | time, xlim=c(85, 103), ylim=c(-7, 7))
# The interactive model time variance slopes appear more deviant in 72 and 672 Hours than in the additive model.

residualPlots(c2.m, terms= ~ 1 | treatment, xlim=c(85, 103), ylim=c(-7, 7))
# The treatment residuals variance slopes show Control has less residual homogeneity across fitted values in the additive model.
residualPlots(c8.m, terms= ~ 1 | treatment, xlim=c(85, 103), ylim=c(-7, 7))
# The treatment residuals variance slopes look similar. Control has more constant slope in   
# the interaction model.

# Visualise multiline graphs for fit (adjusted means)

plot(Effect(c("time", "treatment"), c2.m, residuals = TRUE),
     partial.residual = list(lty = ""), ylim={c(86, 101)}, ci.style="bars",
     lines = list(multiline = TRUE, col=c("yellowgreen", "goldenrod", "forestgreen")),
     ylab = "Covariance controlled final weight mean (mg)",
     main = "Additive model: time & treatment effect on the model \nusing the initial weight mean (mg) average")

plot(Effect(c("time", "treatment"), c8.m, residuals = TRUE),
     partial.residual = TRUE, ylim={c(86, 101)}, CIs = F,
     lines = list(multiline = TRUE, col=c("yellowgreen", "goldenrod", "forestgreen")),
     ylab = "Covariance controlled final weight mean (mg)",
     main = "Interactive model: time & treatment effect on the mean \nusing the initial weight mean average to control pre-test post-test correlation")

anova(c2.m, c8.m)
# The additive and treatment * time interactive models are not significantly
# different (Df = 6, F = 1.19, P = 0.33), however, the 'Effect combinations' plots 
# shows the adjusted means (Blue dot) in the interactive model fit better to the 
# partial residual means (Magenta dot) but with larger CI. Note: The Effect plots are adjusted means, 
# and, the partial residuals are from replicate plate (n=4) variance not seed variance (n=31).

anova(c8.m)
# No significant treatment * time interaction on the final mean when 
# controlling for the initial weight (P>.033). Continue with c2.m.

# Check linear relationship between the response and covariate at each group
# level: Accepted in first ggplot. Alternative (https://www.datanovia.com/en/lessons/ancova-in-r/#check-assumptions-1):

library(ggpubr)
ggscatter(
  c2, x = "initialmeanmg", y = "finalmeanmg",
  facet.by  = c("treatment", "time"), 
  short.panel.labs = FALSE
)+
  stat_smooth(method = "loess", span = 0.9)

# Check there is no interaction between the covariate and the other predictors (Homogeneity of regression slopes)
# c2 %>% anova_test(finalmeanmg ~ treatment*initialmeanmg) # OK P = 0.81 (original for one-way ANCOVA)
# c2 %>% anova_test(finalmeanmg ~ time*initialmeanmg) # OK P = 0.96 (original for one-way ANCOVA)

c2 %>% anova_test(
  finalmeanmg ~ initialmeanmg*treatment +
    initialmeanmg*time + initialmeanmg*time*treatment)
# There was homogeneity of regression slopes as the interaction terms, between the covariate (initialmeanmg) and 
# grouping variables (treatment and time), was not statistically significant, p >0.70

# Datanovia residual normality test (Alternative to what follows) https://www.datanovia.com/en/lessons/ancova-in-r/

c <- augment(c2.m) %>% select(-.hat, -.sigma, -.fitted)
head(c, 3)
shapiro_test(c$.resid)
# Datanovia technique we can assume normality P > 0.20

# Datanovia heteroscedasticity test (Alternative to what follows) 

c %>% levene_test(.resid ~ treatment) 
# Both treatment and time seem OK P>.08

# Datanovia outliers test (Alternative to what follows)

c %>% filter(abs(.std.resid) > 3) %>% as.data.frame()
# No residual outliers

# CHECK NORMALITY AND HOMOSCEDASTICITY

densityPlot(c2.m$residuals, xlab="Residuals")
# May be slightly right-skewed.

skewness(c2.m$residuals)
# The residuals are moderately right skewed (SD = 0.68 = <1.96 = P>.05). Null accepted.

# agostino.test() suggests non-normal distribution. Agostino is not in any 
# advanced books I saw or EDA content so not used here.

shapiro.test(c2.m$residuals)
# Fail to reject normal distribution of residuals (W = 0.96712, P = 0.2).

qqPlot(c2.m$residuals, xlab="Normal quantiles", ylab="Residuals")
# Within 95% pointwise envelope. Row 14 possible outlier.

influenceIndexPlot(c2.m) # Cooks distances <1 suggesting no severe model influencers.
# Row 14 insignificant outlier (B'feroni P>0.1). 

influencePlot(c2.m)
# Rows 24 & 40 hat-value OK. <2x average https://www.rdocumentation.org/packages/VGAM/versions/1.1-5/topics/hatvalues
# Cook'sD <0.5 Ok.

# Hat values x 2
h <- as.data.frame(hatvalues(c2.m))
mean(h$`hatvalues(c2.m)`)*2

# Simulated dispersion test
c2simulationOutput <- simulateResiduals(fittedModel = c2.m, n=1000)
plot(c2simulationOutput)
# No over dispersion (P = 0.512). No outliers (P = 1). Normal distribution (P = 0.76).
# Residual v predicted distribution Ok.

# Test homogeneity of variance 

bartlett.test(c2.m$residuals ~ treatment, data = c2)
bartlett.test(c2.m$residuals ~ time, data = c2)
bartlett.test(c2.m$residuals ~ rep, data = c2)
# Fail to reject homogeneity of residuals on treatment, time and rep (P>.10).

kurtosis(c2.m$residuals) # Test as bp sensitive to kurtosis.
kurtosis.norm.test(c2.m$residuals) # Fail to reject kurtosis normality (T = 3.27, P=0.67)
bptest(c2.m)
# Fail to reject the null hypothesis of model homoscedasticity (BP=9.87, Df=6. P=0.13).
                                                           
# Parameter estimates and standard errors

summary(c2.m)

# The treatment slopes have equal regression coefficients from the covariate: 0.98.
# Treatments S and D have similar intercepts (S -0.51, D -0.48), close (~5mg-less) than the  
# control intercept (23.74). The Control SE (9.3135) is >10X other treatment SE's 
# (S .7746, D .7960) probably due to row 14, which has the highest unexplained 
# variance (3.19mg) in the c2 dataset residual errors. ANOVA finds there is no 
# significant difference between treatments, however there is a 
# significant difference in intercepts across time (P<.001).

# CI's regression coefficient

confint(c2.m)
# Treatment S and D CI's span zero, highlighting no significant difference to control.

# ANOVA

anova(c2.m)
# ANOVA shows an overall significant effect of initial weight mean on final weight
# means (F 1,41 = 28.342, P<.0001), a significant effect of time on  
# final weight means (F 3,41 = 17.858, P<.0001) and no significant difference 
# between treatment on final weight means (F 2,41 = 1.153, P=.325) when 
# controlling for the initial weight means.

# When tested with a treatment * time interaction (c8.m), there was no evidence 
# of a significant interaction (F 6,35 = 1.19, P = .33) hence the interaction 
# was not included to negate unnecessary regressors reducing model power.

# Contrasts to test Null hypothesis 1 & 2 ####

# Hypothesis 1. H0 There is no significant difference in weight change (mg) 
# between treatments after a set duration of imbibition.

# Hypothesis 2. H0 There is no significant difference in weight change (mg) 
# for a single treatment after different durations of imbibition.

# Test Null hypothesis 1
emmeans(c2.m, pairwise ~ treatment | time)
# To test Null hypothesis 1, estimated marginal means were compared using
# multiple-comparison adjusted p-values with Tukey's method for 3 estimates.
# The test found no significant adjusted mean weight differences between treatments 
# at different durations (Df = 41, P>0.79). Null hypothesis 1 was not rejected.

plot(emmeans(c2.m, pairwise ~ treatment | time), CIs = F)# Add comparisons = TRUE for contrast lines
# Visualise 95% CI's NEVER use CI to perform comparisons, use comparisons true or better pwpp(mdl)

# Publication graph with SE bars. Interaction used and stated in text to show relative variance ####
# Publication graph 1
emmeansinteractive <- read.csv("Projects/Absorption/672/emmeansinteractive.csv")
str(emmeansinteractive)
emmeansinteractive$time <- as.factor(emmeansinteractive$time) 
emmeansinteractive$treatment <- as.factor(emmeansinteractive$treatment)
emmeansinteractive$treatment <- factor(emmeansinteractive$treatment, levels = c("control", "s", "d"))

dodge <-  position_dodge(width = 0.1)
ggplot(emmeansinteractive, aes(x = time, y = emmean, colour = treatment, group = treatment)) +
  geom_point(size = 2.5, position = dodge) +
  guides(colour = guide_legend(override.aes = list(linetype = 0))) +
  geom_line(size = 1) +
  geom_errorbar(aes(ymin = emmean - se, ymax = emmean + se), width = 0.1, position = dodge) +
  scale_colour_manual("Treatment", values = c("yellowgreen", "goldenrod", "forestgreen")) +
  scale_y_continuous(breaks=seq(88,100, 2), sec.axis = dup_axis(name = NULL)) +
  xlab("Imbibition duration (Hours)") +
  ylab("Mean (mg) and Standard error bars") +
  ggtitle("") +
  theme_classic() +
  theme(plot.margin = unit(c(0,2,2,2), "mm"), legend.position="top", legend.direction='vertical', 
        panel.border = element_rect(colour = "black", fill=NA), 
        plot.title = element_text(hjust = 0.5, size = 12, face="bold"),
        axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0)))
# Publication graph 2
germinationpublicationplots <- read.csv("Projects/Absorption/672/germinationpublicationplots.csv")
germinationpublicationplots <- germinationpublicationplots[-(13:18), -5]
germinationpublicationplots$time <- as.factor(germinationpublicationplots$time) 
germinationpublicationplots$treatment <- as.factor(germinationpublicationplots$treatment)
germinationpublicationplots$pgerm <- as.numeric(germinationpublicationplots$pgerm)
germinationpublicationplots$treatment <- factor(germinationpublicationplots$treatment, levels = c("control", "s", "d"))
str(germinationpublicationplots)

ggplot(germinationpublicationplots, aes(x = time, y = pgerm, colour = treatment, group = treatment)) +
  geom_point(size = 2.5) +
  guides(colour = guide_legend(override.aes = list(linetype = 0))) +
  geom_line(size = 1) +
  scale_colour_manual("Treatment", values = c("yellowgreen", "goldenrod", "forestgreen")) +
  xlab("Imbibition duration (Hours)") +
  ylab("Germination (%) within 30 days") +
  ggtitle("") +
  scale_y_continuous(limits = c(0, 10), breaks=(seq(1, 11, 2))) +
  theme_classic() +
  theme(panel.border = element_rect(colour = "black", fill=NA))

# Standard deviations and errors of reps

SD <- ab[1:1488,] %>%
  group_by(treatment, time, rep.no) %>%
  summarise(
    InitialWeightMean = mean(weight), Iwm.SD  = sd (weight),
    Iwm.SE = sd(weight)/sqrt(n())) %>% ungroup() %>% as.data.frame
sd. <- ab[1489:2976,] %>%
  group_by(treatment, time, rep.no) %>%
  summarise(
    FinalWeightMean = mean(weight), Fwm.sd  = sd (weight),
    Fwm.se = sd(weight)/sqrt(n())) %>% ungroup() %>% as.data.frame
# sd-within final weights may be misleading as it does not account for the final weight correlation 
# with initial weight presented if explained within png.
SD$FinalWeightMean <- sd.$FinalWeightMean
SD$Fwm.SD <- sd.$Fwm.sd
SD$Fwm.SE <- sd.$Fwm.se

# For publication Means, SD, SE between plates for Table 6 ####

SD <- c2 %>%
  group_by(treatment, time) %>%
  summarise(
    `DryWeightMean (mg)`= mean(initialmeanmg), `Dry SD`  = sd (initialmeanmg),
    `Dry SE` = sd(initialmeanmg)/sqrt(n())) %>% ungroup() %>% as.data.frame

SD. <- c2 %>%
  group_by(treatment, time) %>%
  summarise(
    `ImbibedWeightMean (mg)`= mean(finalmeanmg), `Imb SD`  = sd (finalmeanmg),
    `Imb SE` = sd(finalmeanmg)/sqrt(n())) %>% ungroup() %>% as.data.frame

SD.. <- c2 %>%
  group_by(treatment, time) %>%
  summarise(
    `Absolute dif (mg)`= mean(abdif), `Absdif SD`  = sd (abdif),
    `Absdif SE` = sd(abdif)/sqrt(n())) %>% ungroup() %>% as.data.frame

SD... <- c2 %>%
  group_by(treatment, time) %>%
  summarise(
    `% dif`= mean(pcdif), `% SD`  = sd (pcdif),
    `% SE` = sd(pcdif)/sqrt(n())) %>% ungroup() %>% as.data.frame

SD$`ImbibedWeightMean (mg)` <- SD.$`ImbibedWeightMean (mg)`
SD$`Imb SD` <- SD.$`Imb SD`
SD$`Imb SE` <- SD.$`Imb SE`

SD$`Absolute dif (mg)` <- (SD$`ImbibedWeightMean (mg)`-SD$`DryWeightMean (mg)`)
SD$`Absdif SD` <- SD..$`Absdif SD` # SD and SE of Abdif between replicates
SD$`Absdif SE` <- SD..$`Absdif SE`

SD$ `% dif` <- (SD$`ImbibedWeightMean (mg)` - SD$`DryWeightMean (mg)`) / (SD$`DryWeightMean (mg)`) * 100
SD$`%dif SD` <- SD...$`% SD` # SD and SE of % dif between replicates
SD$`%dif SE` <- SD...$`% SE`

# Add emmeans from the hypothesis-tested model (c2.m) to the SD data.frame
emmeansadditive <- read.csv("Projects/Absorption/672/emmeansadditive.csv")
emmeansadditive <- emmeansadditive[-(13:17),-5]
str(emmeansadditive)
emmeansadditive$time <- as.factor(emmeansadditive$time) 
emmeansadditive$treatment <- as.factor(emmeansadditive$treatment)
emmeansadditive$treatment <- factor(emmeansadditive$treatment,levels = c("control", "s", "d"))
# reorder by rows to match SD####
emmeansadditive <- emmeansadditive[with(emmeansadditive, order(treatment)), ]
row.names(emmeansadditive) <- NULL
SD$`Emmeans (mg)`<- emmeansadditive$emmean
SD$` Emmeans SE` <- emmeansadditive$se
SD <- SD %>% mutate_if(is.numeric, round, digits = 2) 
write.table(SD, file = "672SD.txt", sep = ",", quote = FALSE, row.names = F)
#Open file in text reader. Copy-paste to word. Select all in word convert to table.

# Proof emmeans for optimal test controlling for 
# initial mean weight. Below is non-covariate exact-mean emmeans match (not THE model)
meantest.m <- lm(finalmeanmg ~ treatment * time, data = c2)
emmeans(meantest.m, pairwise ~ treatment| time)
(93.64516+96.51613+98.12903+93.19355)/4 # 72 control
(90.96774+94.80645+90.32258+98.74194)/4 # 168 d
# and without the covariate to see the difference after it is controlled for
c.m <- lm(finalmeanmg ~ treatment + time, data = c2)
emmeans(c.m, pairwise ~ treatment | time)

# Test Null hypothesis 1 with exact p-value adjust
emmeans(c2.m, pairwise ~ treatment | time, adjust = "mvt")
# Results as emmeans default

# Test Null hypothesis 2
emmeans(c2.m, pairwise ~ time | treatment)
# To test Null hypothesis 2, estimated marginal means were compared using
# multiple-comparison adjusted p-values with Tukey's method for 4 estimates. 
# The test found significant adjusted mean weight differences for every treatment
# from 72 to all other hours of imbibition (Df = 41, P<0.01) and for every
# treatment from 168 to 672 hours (Df = 41, P<0.05). Weight differences from 
# 168 to 336 and 336 to 672 hours were not significantly different (Df = 41, P>0.07).
# Null hypothesis 2 was rejected, time had a significant effect on final weight.

plot(emmeans(c2.m, pairwise ~ time | treatment)) 
# Visualise 95% CI's

# Percentage difference table (Not Used. The percentages for report v.1 Table 6
# were generated from the replicate-averaged mean weights for the 672SD.txt file above.
write.csv(round(xtabs(c2$pcdif ~ rep + treatment + time, data = c2), 1), "percentd.csv")

# Differences in germination by predictors####

# Original indices are in germinationtest.csv. Replicates combined:

gt <- data.frame(
  treatment = factor(rep(c("control", "s", "d"), c(4, 4, 4)),
                     levels = c("control", "s", "d")),
  time = factor(rep(c("72", "168", "336", "672"), 3),
                levels = c("72", "168", "336", "672")),
  germ = c(8, 5, 9, 3, 6, 11, 6, 9, 2, 9, 7, 1),
  dorm = c(23, 26, 22, 28, 25, 20, 25, 22, 29, 22, 24, 30))
gt
str(gt)

# Exploratory graph

hist(gt$germ)

ggplot(gt, aes(x = time, y = germ, colour = treatment)) +
  geom_point(size = 4) +
  xlab("Hours of imbibition") +
  ylab("Final germinants 30 days after imbibition") +
  scale_y_continuous(breaks = seq(0, 14, by = 1)) +
  theme_classic()
# There appears to be no treatment trends in final germinants although 168
# hours has the highest germinants, 11, with treatment s, and 672 hours
# the lowest germinants, 1, with treatment d.

# Residual normality is non-prerequisite for generalised linear models. Dispersion and outliers  were
# tested.
# Independent and random sampling from the provenance batch is met.

# Model ####

gt.m <- glm(cbind(germ, dorm) ~ treatment + time, 
              family=binomial, data=gt)

# glmer(cbind(germinate, not.germinate) ~ treatment + time + (1|rep), family=binomial, data=gm) If including 
# random between plate error, not enough plates here (<5): https://www.mdpi.com/2306-5729/5/1/6/htm
# and https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3321166/pdf/embor201236a.pdf
# After combining possibly still too-low counts per cell (<5) for meaningful chi-square without adjustment.

# Compare models with and without interaction.

gt.mi <- glm(cbind(germ, dorm) ~ treatment * time, 
            family=binomial, data=gt)

# Test for significance between the interactive and additive models

anova(gt.m, gt.mi, test = "Chisq")
# The null hypothesis of no significant effect of a treatment * time
# interaction in model fit can be rejected (Deviance = 13.79, Df = 6, P = 0.03)  
# The anova finds a significant difference from the interaction term.

Anova(gt.mi)
# The type 2 sequential test on the interaction model finds the treatment *
# time interaction has a significant effect on the germination probability.

# Test fit ####

# Check dispersion

summary(gt.m)
# 13.788/6 = 2.3. Rule of thumb <2 Ok. Consider sample size.

summary(gt.mi)
# Saturated model has no residuals to check.

gtmid <- simulateResiduals(fittedModel = gt.mi, n=2500) # against 2500 simulated datasets from the model.
plot(gtmid, quantreg = T)
# Significant QQplot and residual v predicted deviation

# Check fixed model dispersion

gtmd <- simulateResiduals(fittedModel = gt.m, n=2500)
plot(gtmd, quantreg = T)
# Significant residuals v predicted deviation

# Use a data.frame with separate replicates

gtfull <- read.csv("Projects/Absorption/672/germinationtest.csv")
str(gtfull)
gtfull$id <- as.factor(gtfull$id)
gtfull$treatment <- as.factor(gtfull$treatment)    
gtfull$treatment <- factor(gtfull$treatment,levels = c("nt", "s", "d"))
levels(gtfull$treatment) <- c("control", "s", "d")
gtfull$time <- as.factor(gtfull$time)
gtfull$time <- factor(gtfull$time,levels = c("72 Hours", "168 Hours", "336 Hours", "672 Hours"))
levels(gtfull$time) <- c("72", "168", "336", "672")
gtfull$rep <- as.factor(gtfull$rep) 
gtfull$germinate <- as.numeric(gtfull$germinate)             
gtfull$not.germinate <- as.numeric(gtfull$not.germinate)
colnames(gtfull) <- c("id", "treatment", "time", "rep", "germ", "dorm")
levels(gtfull$treatment)
levels(gtfull$time)
str(gtfull)

# Compare models with and without interaction.

gtf.m <- glm(cbind(germ, dorm) ~ treatment + time, 
            family=binomial, data=gtfull)

gtf.mi <- glm(cbind(germ, dorm) ~ treatment * time, 
             family=binomial, data=gtfull)

anova(gtf.m, gtf.mi, test = "Chisq")
# The anova finds the interaction not significant at the 0.05 level. 
# (Deviance = 12.107, Df = 6, P = 0.06). But it's close.

# Compare model dispersion (Primarily to elucidate non-independence) (If caused by mixing variables try a different model family e.g. if poisson try quasi poisson then test = F instead of Chisq see Beckerman et al.2017)

summary(gtf.m)
# 66.707/42 = 1.6 Rule of thumb <2 OK, also consider sample size.

summary(gtf.mi)
# 54.601/36 = 1.5

# DHARMa plots 

gtfmd <- simulateResiduals(fittedModel = gtf.m, n=2500)
plot(gtfmd, quantreg = T)
# Dispersion OK (P = 0.37). Distribution OK (P = 0.84). No outliers (P = 1). 
# Residual v predicted "uniform distribution of residuals" Ok.

# Interactive model
gtfmid <- simulateResiduals(fittedModel = gtf.mi, n=2500)
plot(gtfmid, quantreg = T)
# Dispersion OK (P = 0.81). Distribution OK (P = 0.71). No outliers (P = 1). 
# Residual v predicted "uniform distribution of residuals" Ok.

# Check within group error uniformity

x1 = recalculateResiduals(gtfmd, group = gtfull$treatment)
plot(x1, asFactor = TRUE, quantreg = T)
# Quantreg default is F over n=2000. T better https://cran.r-project.org/web/packages/DHARMa/DHARMa.pdf
# Treatment residual uniformity n.s.

x2 = recalculateResiduals(gtfmd, group = gtfull$time)
plot(x2, asFactor = TRUE, quantreg = T)
# Time residual uniformity n.s.

# Interactive model

x3 = recalculateResiduals(gtfmid, group = gtfull$treatment)
plot(x3, asFactor = TRUE, quantreg = T)
# Treatment residual uniformity n.s.

x4 = recalculateResiduals(gtfmid, group = gtfull$time)
plot(x4, asFactor = TRUE, quantreg = T)
# Time residual uniformity n.s.

# Check within group homoscedasticity

plotResiduals(gtfmd, gtfull$treatment, quantreg = T) 
# Homoscedasticity n.s.

plotResiduals(gtfmd, gtfull$time, quantreg = T)
# Homoscedasticity n.s.

# Interactive model

plotResiduals(gtfmid, gtfull$treatment, quantreg = T)
# Homoscedasticity n.s. 

plotResiduals(gtfmid, gtfull$time, quantreg = T)
# Homoscedasticity n.s.

# Beckerman et al. diagnostics (Not)

autoplot(gtf.m, smooth.colour = NA)
# Better than gt.m

autoplot(gtf.mi, smooth.colour = NA)
# OK. Warnings to do with x/ylims. Cannot see where. Not using these plots as keystones.

# Zero inflation a source of overdispersion: 

testZeroInflation(gtf.m) # (P = 0.48)
testZeroInflation(gtf.mi) # (P = 1)

# Move forward with interactive model as better zero inflation and res vs pred uniformity.

# Contrasts to test Null hypothesis 3 and 4 ####

# Hypothesis 3. H0 There is no significant difference in germination probability 
# between treatments within 30 days after a set duration of imbibition.

# Hypothesis 4. H0 There is no significant difference in germination probability 
# from the same treatment after different durations of imbibition.

# Test Null hypothesis 3
emmeans(gtf.mi, 
        pairwise ~ treatment | time, type = "response") # Remove $contrasts to see means
# To test Null hypothesis 3, estimated marginal means were compared in the
# log odds scale from the logit linear predictor. The multiple-comparisons used 
# adjusted p-values using Tukey's method for 3 estimates. The test found no significant 
# difference in germination probability between treatments within 30 days after a 
# set duration of imbibition (P>0.08). Null hypothesis 3 was not rejected.
emmip(gtf.mi, treatment ~ time, type = "response")
plot(emmeans(gtf.mi, pairwise ~ treatment | time, type = "response")) 
# Visualise 95% CI's

# Test Null hypothesis 4
emmeans(gtf.mi, 
        pairwise ~ time | treatment, type = "response")
# To test Null hypothesis 4, estimated marginal means were compared in the
# log odds scale from the logit linear predictor. The multiple comparisons used
# adjusted p-values using Tukey's method for 4 estimates. The test found no 
# significant difference in germination probability from the same treatment after 
# different durations of imbibition. (P>0.1). Null hypothesis 4 was not rejected.

plot(emmeans(gtf.mi, pairwise ~  time | treatment, type = "response"))
# Visualise 95% CI's

# Visualise germination probabilities

plot(predictorEffects(gtf.mi, ~ time),
     main = "",
     confint = list(style = "bars"),
     lines = list(multiline = TRUE, col=c("yellowgreen", "goldenrod", "forestgreen")),
     axes=list(y=list(type="response")),
     xlab ="imbibition (hours)", grid=TRUE,
     ylab = "Probability")

# The vertical axis shows the probabilities of germination within 30 days after 
# after imbibition with the tested parameters. The plot points show respective 
# parameter-combinative germination probability. There is a range of probabilities
# and no parametric trends, although treatment d's probability declines monotonically
# at 336 and 672.

# Treatment s after 168 hours has the highest relative probability of germination
# in the tested parameters (conditions) (0.09, 95% CI = 0.05 - 0.15); 
# Treatment d after 672 hours has the lowest (<0.01, 95% CI = <0.01 - 0.05). 
# The second highest likelihood of germination in the tested conditions are
# similar between control after 72 (0.06, 95% CI = 0.03 - 0.12) and 336 hours
# (0.07, 95% CI = 0.04 - 0.13), d with 168 hours (0.07, 95% CI = 0.04 - 0.13) and
# s with 672 hours (0.07, 95% CI = 0.4 - 0.13).

# An inverse relationship between control and s germination probabilities 
# at different durations is seen in the graph.

# Probability estimates and confidence intervals (not in log scale)

gtf.mie <- Effect(c("treatment", "time"), gtf.mi)
summary(gtf.mie)

# Overall model analysis of deviance test (Likelihood ratio test)

anova(gtf.mi, test = "Chisq")
# The probability of germination within 30 days after imbibition
# did not significantly vary from treatment (D = 3.54, Df = 2, p = 0.17) 
# or time (D = 5.07, Df = 3, p = 0.17).

# Inference from the germinant results apply to unstratified seed of this batch 
# only although results may provide speculative inference for the species 
# until more knowledge is gathered.

# Study notes: Maximise plates >5 ideally >10. Find more robust ways to remove excess water straight out of imbibition 
# for reduced potential error across weights.

# End.

# Dispersion re modelling 22/06/2021 19:47 (not used) #### 

# This section goes against the minimum 5 plates for random effects, out of 
# curiosity, to test simulated dispersion.

# summary() finds the RE between-replicate variance is 0 i.e. not-significant.
# Detail below.

# https://cran.r-project.org/web/packages/DHARMa/vignettes/DHARMa.html#binomial-data

# Mixed-model additive

gtr.m <- glmer(cbind(germ, dorm) ~ treatment + time + (1|rep), 
               family=binomial, data=gtfull)
gtrmd <- simulateResiduals(fittedModel = gtr.m)
plot(gtrmd)
# No significant deviation detected.

# Mixed-model with interaction

gtr.mi <- glmer(cbind(germ, dorm) ~ treatment * time + (1|rep),
                family=binomial, data=gtfull)
gtrmid <- simulateResiduals(fittedModel = gtr.mi)
plot(gtrmid)
# Predicted vs residual deviation detected in some simulations but combined n.s. 
# Close to mixed-model additive model. May be an unnecessarily over-fit model.

# Compare mixed models

anova(gtr.mi, gtr.m, test = "Chisq")
# The mixed-model binomial generalised linear model with interaction 
# is not significantly different to the additive model but the difference is 
# close to significant (X2 = 12.107, Df = 6, P  = 0.059).
# AIC scores are close (0.11 AIC points).

# Test interaction with type 2 ANOVA

Anova(gtr.mi)
# The interaction term is found not significant
# (X2 = 10.57 Df = 6, P = 0.10).

summary(gtr.m)
# The level of between replicate variance is 0 i.e. not-significant for both RE
# models. The variation between the plates is accounted for by expected
# distribution. Continue out of interest.

xtabs(~treatment + time + rep, data = gtfull)

# Proceed with mixed-effect additive model

# Test for zero inflation

testZeroInflation(gtrmd)
# Ratio near 1 should be Ok (1.21). Slightly more zeros than the simulation expected. https://www.rdocumentation.org/packages/DHARMa/versions/0.4.1/topics/testZeroInflation

# Visualise probability

plot(predictorEffects(gtr.m, ~ treatment),
     main = "",
     confint = list(style = "bars"),
     lines = list(multiline = TRUE),
     xlab ="Treatment",
     ylab = "Probability of germination within 30 days after imbibition")
# The predictorEffects plot shows treatment S has the highest germination probability 
# (0.06, 95% CI = 0.04-0.09) and d the lowest (0.04, 95% CI = 0.02-0.06) with
# control germination probability (0.05, 95% CI = 0.03-0.07) ceteris paribus. 
# The overlapping 95% confidence bars suggest differences in probabilities 
# are not significant.

# Treatment probability and confidence intervals (CI) not in log odds scale

treatmenteff.gtrm <- Effect(c("treatment"), gtr.m)
summary(treatmenteff.gtrm)

plot(predictorEffects(gtr.m, ~ time),
     main = "",
     confint = list(style = "bars"),
     lines = list(multiline = TRUE),
     xlab ="Imbibition duration",
     ylab = "Probability of germination within 30 days after imbibition")
# Spot the pattern? It follows the ggplot exploratory graph d curve.
# The predictorEffects plot shows 168 hours is the imbibition duration giving the 
# highest probability of germination (0.07, 95% CI = 0.04-0.10), the lowest 
# is 672 hours (0.03, 95% CI = 0.02-0.06). In between are 336 (0.06, 95% CI = 0.04-0.09) 
# followed by 72 hours (0.04, 95% CI = 0.03-0.07). The 95% confidence bars 
# overlap suggesting the differences are not significant.

# Time probability and confidence intervals (CI) not in log odds scale

timeeff.gtrm <- Effect(c("time"), gtr.m)
summary(timeeff.gtrm)

# Test Null hypothesis 3 with the mixed effect additive model.
emmeans(gtr.m, 
        pairwise ~ treatment | time)$contrasts 
# Null 3 not rejected. (P>0.10).

# Test Null hypothesis 4 with the mixed effect additive model.
emmeans(gtr.m, 
        pairwise ~ time | treatment)$contrasts
# Null 4 not rejected (P>0.20). 

# End of mixed model exercise.

# simple reporting e.g. weight ####
ed0 <- lm(abdif ~ treatment * time, data = c2)
anova(ed0)
interaction.plot(x.factor = c2$time,
                 trace.factor = c2$treatment,
                 response = c2$abdif)


# final weight and germination (not used) ####
# Any trends between final mean and germination probability
# many variations of below with initial and final means tested no 
# significant trends. Future: more replicate plates and categorised dry weights 
# would statistically further scrutinize germination.
gtfull$pcdif <- c2$pcdif
gtfull$initialmeanmg <- c2$initialmeanmg
gtf.mfm <- glm(cbind(germ, dorm) ~ treatment * time * initialmeanmg, 
              family=binomial, data=gtfull)

anova(gtf.mi, gtf.mfm, test = "Chisq")

Anova(gtf.mfm)

summary(gtf.mfm)

plot(predictorEffects(gtf.mfm),
     main = "",
     confint = list(style = "bars"),
     lines = list(multiline = TRUE, col=c("yellowgreen", "goldenrod", "forestgreen", "lightblue", "orange3")),
     axes=list(y=list(type="response")),
     xlab ="", grid=TRUE,
     ylab = "Probability")
